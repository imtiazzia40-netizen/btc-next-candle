package com.example.btcnc.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.btcnc.data.Candle
import com.example.btcnc.data.Prediction
import com.example.btcnc.logic.Predictor
import com.example.btcnc.repo.MarketRepo
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class UiState(
    val symbol: String = "BTCUSDT",
    val candles: List<Candle> = emptyList(),
    val predicted: Prediction? = null,
    val auto: Boolean = false
)

class MainViewModel: ViewModel() {
    private val repo = MarketRepo()
    private val _uiState = MutableStateFlow(UiState())
    val uiState = _uiState.asStateFlow()

    private var autoJob: Job? = null

    fun setSymbol(s: String) { _uiState.value = _uiState.value.copy(symbol = s.uppercase()) }

    fun refresh() {
        viewModelScope.launch {
            val data = runCatching { repo.fetch5m(_uiState.value.symbol, 240) }.getOrElse { emptyList() }
            val pred = Predictor.predict(data)
            _uiState.value = _uiState.value.copy(candles = data, predicted = pred)
        }
    }

    fun toggleAuto() {
        if (_uiState.value.auto) {
            autoJob?.cancel()
            _uiState.value = _uiState.value.copy(auto = false)
        } else {
            _uiState.value = _uiState.value.copy(auto = true)
            autoJob = viewModelScope.launch {
                while (true) {
                    refresh()
                    delay(60_000L)
                }
            }
        }
    }

    override fun onCleared() {
        autoJob?.cancel()
        super.onCleared()
    }
}
