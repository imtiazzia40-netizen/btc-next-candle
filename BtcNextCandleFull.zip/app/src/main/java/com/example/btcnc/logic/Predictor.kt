package com.example.btcnc.logic

import com.example.btcnc.data.*
import kotlin.math.max
import kotlin.math.min

object Predictor {
    data class Context(
        val ema20: Double,
        val ema50: Double,
        val rsi: Double,
        val macd: Double,
        val signal: Double,
        val atr: Double,
        val avgBody: Double
    )

    fun predict(series: List<Candle>): Prediction? {
        if (series.size < 60) return null
        val closes = series.map { it.close }
        val ema20 = closes.ema(20).lastOrNull() ?: return null
        val ema50 = closes.ema(50).lastOrNull() ?: return null
        val rsi = closes.rsi(14).lastOrNull() ?: return null
        val (macd, signal, _) = closes.macd()
        val macdL = macd.lastOrNull() ?: return null
        val signalL = signal.lastOrNull() ?: return null
        val atr = series.atr(14).lastOrNull() ?: return null
        val last = series.last()
        val avgBody = series.takeLast(20).map { kotlin.math.abs(it.close - it.open) }.average()

        val ctx = Context(ema20, ema50, rsi, macdL, signalL, atr, avgBody)
        return nextCandleFromContext(last, ctx)
    }

    private fun nextCandleFromContext(last: Candle, c: Context): Prediction {
        val upTrend = c.ema20 > c.ema50
        val priceAboveEma = last.close > c.ema20
        val momentumUp = c.macd > c.signal && c.rsi >= 50
        val momentumDown = c.macd < c.signal && c.rsi <= 50

        val bias = when {
            upTrend && priceAboveEma && momentumUp && c.rsi < 80 -> Bias.Bullish
            !upTrend && !priceAboveEma && momentumDown && c.rsi > 20 -> Bias.Bearish
            else -> Bias.Neutral
        }

        val body = when (bias) {
            Bias.Bullish -> c.avgBody * 1.1
            Bias.Bearish -> c.avgBody * 1.1
            Bias.Neutral -> c.avgBody * 0.5
        }.coerceAtLeast(c.atr * 0.15)

        val estOpen = last.close
        val estClose = when (bias) {
            Bias.Bullish -> estOpen + body
            Bias.Bearish -> estOpen - body
            Bias.Neutral -> estOpen + (if (c.macd >= c.signal) body * 0.2 else -body * 0.2)
        }

        val range = max(c.atr * 0.6, body * 1.2)
        val estHigh = max(estOpen, estClose) + range * 0.4
        val estLow  = min(estOpen, estClose) - range * 0.4

        val rationale = buildList {
            add("EMA20 ${if (upTrend) ">" else "<"} EMA50: trend ${if (upTrend) "up" else "down"}")
            add("Close ${if (priceAboveEma) ">" else "<"} EMA20: ${if (priceAboveEma) "strength" else "weakness"}")
            add("MACD ${"%.4f".format(c.macd)} vs Signal ${"%.4f".format(c.signal)}")
            add("RSI ${"%.1f".format(c.rsi)}")
            add("ATR ${"%.2f".format(c.atr)}; AvgBody ${"%.2f".format(c.avgBody)}")
        }

        val pred = Candle(
            openTime = last.closeTime + 1,
            open = estOpen,
            high = estHigh,
            low = estLow,
            close = estClose,
            volume = last.volume,
            closeTime = last.closeTime + 5 * 60_000
        )

        val conf = when (bias) {
            Bias.Neutral -> 0.45
            else -> 0.58 + (kotlin.math.min(20.0, kotlin.math.abs(c.macd - c.signal) * 1000) / 100.0) * 0.01
        }.coerceIn(0.3, 0.75)

        return Prediction(pred, bias, conf, rationale)
    }
}
