package com.example.btcnc

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.btcnc.ui.MiniCandleChart
import com.example.btcnc.vm.MainViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    val vm: MainViewModel = viewModel()
                    val state by vm.uiState.collectAsState()

                    Column(Modifier.fillMaxSize().padding(16.dp)) {
                        Text("BTC/USDT • 5m Next-Candle Predictor", style = MaterialTheme.typography.titleLarge)
                        OutlinedTextField(
                            value = state.symbol,
                            onValueChange = { vm.setSymbol(it) },
                            label = { Text("Symbol (Binance)") },
                            singleLine = true
                        )
                        androidx.compose.foundation.layout.Row {
                            Button(onClick = { vm.refresh() }) { Text("Refresh Now") }
                            androidx.compose.foundation.layout.Spacer(modifier = Modifier.weight(1f))
                            Button(onClick = { vm.toggleAuto() }) { Text(if (state.auto) "Stop Auto" else "Start Auto") }
                        }

                        MiniCandleChart(candles = state.candles, predicted = state.predicted?.candle, modifier = Modifier.fillMaxSize().height(240.dp))

                        state.predicted?.let { p ->
                            Text("Bias: ${'$'}{p.bias} • Confidence: ${'$'}{(p.confidence * 100).toInt()}%" )
                            Text("Est. O:${'$'}{"%.2f".format(p.candle.open)} H:${'$'}{"%.2f".format(p.candle.high)} L:${'$'}{"%.2f".format(p.candle.low)} C:${'$'}{"%.2f".format(p.candle.close)}")
                            Divider()
                            Text("Rationale:")
                            p.rationale.forEach { Text("• ${'$'}it") }
                        } ?: Text("Prediction will appear here after first refresh…")
                    }
                }
            }
        }
    }
}
