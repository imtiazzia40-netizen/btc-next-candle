package com.example.btcnc.net

import retrofit2.http.GET
import retrofit2.http.Query

interface BinanceApi {
    @GET("/api/v3/klines")
    suspend fun klines(
        @Query("symbol") symbol: String = "BTCUSDT",
        @Query("interval") interval: String = "5m",
        @Query("limit") limit: Int = 200
    ): List<List<Any>>
}
