package com.example.btcnc.data

import kotlin.math.max
import kotlin.math.min

data class Candle(
    val openTime: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double,
    val closeTime: Long
)

data class Prediction(
    val candle: Candle,
    val bias: Bias,
    val confidence: Double,
    val rationale: List<String>
)

enum class Bias { Bullish, Bearish, Neutral }

fun List<Candle>.atr(period: Int = 14): List<Double> {
    if (isEmpty()) return emptyList()
    val trs = mutableListOf<Double>()
    for (i in indices) {
        val c = this[i]
        val prevClose = if (i == 0) c.close else this[i-1].close
        val tr = max(c.high - c.low, max(kotlin.math.abs(c.high - prevClose), kotlin.math.abs(c.low - prevClose)))
        trs += tr
    }
    val atr = mutableListOf<Double>()
    var sum = 0.0
    for (i in trs.indices) {
        sum += trs[i]
        if (i == period - 1) {
            atr += sum / period
        } else if (i >= period) {
            val prevAtr = atr.last()
            atr += (prevAtr * (period - 1) + trs[i]) / period
        } else {
            atr += Double.NaN
        }
    }
    return atr
}

fun List<Double>.ema(period: Int): List<Double> {
    val out = MutableList(this.size) { Double.NaN }
    if (this.size < period) return out
    var sum = 0.0
    for (i in 0 until period) sum += this[i]
    var prev = sum / period
    out[period-1] = prev
    val k = 2.0 / (period + 1)
    for (i in period until this.size) {
        prev = (this[i] - prev) * k + prev
        out[i] = prev
    }
    return out
}

fun List<Double>.sma(period: Int): List<Double> {
    val out = MutableList(this.size) { Double.NaN }
    var sum = 0.0
    for (i in indices) {
        sum += this[i]
        if (i >= period) sum -= this[i - period]
        if (i >= period - 1) out[i] = sum / period
    }
    return out
}

fun List<Double>.rsi(period: Int = 14): List<Double> {
    if (size < period + 1) return List(size) { Double.NaN }
    val deltas = this.zipWithNext { a, b -> b - a }
    var gain = 0.0
    var loss = 0.0
    for (i in 0 until period) {
        val d = deltas[i]
        if (d >= 0) gain += d else loss -= d
    }
    gain /= period
    loss /= period
    val rsis = MutableList(size) { Double.NaN }
    var rs = if (loss == 0.0) Double.POSITIVE_INFINITY else gain / loss
    rsis[period] = 100 - (100 / (1 + rs))
    val alpha = 1.0 / period
    for (i in period + 1 until size) {
        val d = deltas[i - 1]
        val g = if (d > 0) d else 0.0
        val l = if (d < 0) -d else 0.0
        gain = (gain * (1 - alpha)) + alpha * g
        loss = (loss * (1 - alpha)) + alpha * l
        rs = if (loss == 0.0) Double.POSITIVE_INFINITY else gain / loss
        rsis[i] = 100 - (100 / (1 + rs))
    }
    return rsis
}

fun List<Double>.macd(fast: Int = 12, slow: Int = 26, signalP: Int = 9): Triple<List<Double>, List<Double>, List<Double>> {
    val emaFast = this.ema(fast)
    val emaSlow = this.ema(slow)
    val macd = this.indices.map { i ->
        val f = emaFast.getOrNull(i) ?: Double.NaN
        val s = emaSlow.getOrNull(i) ?: Double.NaN
        if (!f.isNaN() && !s.isNaN()) f - s else Double.NaN
    }
    val signal = macd.ema(signalP)
    val hist = macd.indices.map { i ->
        val m = macd[i]
        val s = signal.getOrNull(i) ?: Double.NaN
        if (!m.isNaN() && !s.isNaN()) m - s else Double.NaN
    }
    return Triple(macd, signal, hist)
}
