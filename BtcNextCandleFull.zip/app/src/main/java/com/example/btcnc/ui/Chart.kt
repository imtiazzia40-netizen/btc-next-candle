package com.example.btcnc.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.btcnc.data.Candle
import kotlin.math.max
import kotlin.math.min

@Composable
fun MiniCandleChart(
    candles: List<Candle>,
    predicted: Candle?,
    modifier: Modifier = Modifier
) {
    if (candles.isEmpty()) return
    val recent = candles.takeLast(60)
    val minP = (recent.minOf { it.low })
    val maxP = (recent.maxOf { it.high })
    val pad = (maxP - minP) * 0.05
    val low = minP - pad
    val high = maxP + pad

    Canvas(modifier = modifier.height(240.dp)) {
        val w = size.width
        val h = size.height
        val step = w / (recent.size + if (predicted != null) 1 else 0)

        fun y(price: Double) = h - ((price - low) / (high - low) * h).toFloat()

        for (i in 0..4) {
            val yy = h * i / 4f
            drawLine(Color(0x22000000), Offset(0f, yy), Offset(w, yy), strokeWidth = 1f)
        }

        recent.forEachIndexed { i, c ->
            val x = step * i + step/2f
            val col = if (c.close >= c.open) Color(0xFF2E7D32) else Color(0xFFC62828)
            drawLine(col, Offset(x, y(c.high)), Offset(x, y(c.low)), strokeWidth = 2f)
            val top = y(max(c.open, c.close))
            val bot = y(min(c.open, c.close))
            drawRect(col, topLeft = androidx.compose.ui.geometry.Offset(x - step*0.15f, top), size = androidx.compose.ui.geometry.Size(step*0.3f, bot - top))
        }

        predicted?.let { p ->
            val i = recent.size
            val x = step * i + step/2f
            val col = Color(0xFF1565C0)
            drawLine(col, Offset(x, y(p.high)), Offset(x, y(p.low)), strokeWidth = 2f)
            val top = y(max(p.open, p.close))
            val bot = y(min(p.open, p.close))
            drawRect(
                color = Color.Transparent,
                topLeft = androidx.compose.ui.geometry.Offset(x - step*0.15f, top),
                size = androidx.compose.ui.geometry.Size(step*0.3f, bot - top),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f)
            )
        }
    }
}
