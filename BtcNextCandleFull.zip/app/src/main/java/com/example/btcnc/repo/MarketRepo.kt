package com.example.btcnc.repo

import com.example.btcnc.data.Candle
import com.example.btcnc.net.BinanceApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory

class MarketRepo {
    private val api: BinanceApi

    init {
        val logging = HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC }
        val client = OkHttpClient.Builder().addInterceptor(logging).build()
        val retrofit = Retrofit.Builder()
            .baseUrl("https://api.binance.com")
            .addConverterFactory(MoshiConverterFactory.create())
            .client(client)
            .build()
        api = retrofit.create(BinanceApi::class.java)
    }

    suspend fun fetch5m(symbol: String = "BTCUSDT", limit: Int = 200): List<Candle> = withContext(Dispatchers.IO) {
        val raw = api.klines(symbol = symbol, interval = "5m", limit = limit)
        raw.map { row ->
            val openTime = (row[0] as Number).toLong()
            val open = (row[1] as String).toDouble()
            val high = (row[2] as String).toDouble()
            val low  = (row[3] as String).toDouble()
            val close= (row[4] as String).toDouble()
            val volume = (row[5] as String).toDouble()
            val closeTime = (row[6] as Number).toLong()
            Candle(openTime, open, high, low, close, volume, closeTime)
        }
    }
}
